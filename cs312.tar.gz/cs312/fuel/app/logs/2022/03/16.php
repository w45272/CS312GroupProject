<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2022-03-16 13:50:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-16 14:00:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-16 14:01:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-16 14:02:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-16 14:02:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-16 14:04:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-16 14:05:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-16 14:06:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-16 14:06:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
