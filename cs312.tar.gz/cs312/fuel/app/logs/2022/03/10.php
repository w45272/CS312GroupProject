<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

WARNING - 2022-03-10 12:33:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:33:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:33:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:35:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:50:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:50:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:51:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:53:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:53:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:53:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:53:24 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 12:53:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:03:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:03:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:03:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:09:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:09:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:09:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2022-03-10 13:09:07 --> Notice - Undefined variable: nav_bar in /home/kathy/cs312/fuel/app/views/template.php on line 12
WARNING - 2022-03-10 13:09:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2022-03-10 13:09:21 --> Error - The requested view could not be found: project/generator.php in /home/kathy/cs312/fuel/core/classes/view.php on line 492
WARNING - 2022-03-10 13:09:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:11:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:11:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:11:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:11:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:15:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2022-03-10 13:15:50 --> Error - syntax error, unexpected '$this' (T_VARIABLE) in /home/kathy/cs312/fuel/app/classes/controller/project.php on line 32
WARNING - 2022-03-10 13:16:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2022-03-10 13:16:16 --> Notice - Undefined variable: title in /home/kathy/cs312/fuel/app/views/project/header.php on line 3
WARNING - 2022-03-10 13:17:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2022-03-10 13:17:36 --> Notice - Undefined variable: data in /home/kathy/cs312/fuel/app/views/project/header.php on line 3
WARNING - 2022-03-10 13:23:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:23:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
ERROR - 2022-03-10 13:23:08 --> Notice - Undefined variable: header in /home/kathy/cs312/fuel/app/views/template.php on line 6
WARNING - 2022-03-10 13:23:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:24:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:25:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:25:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:25:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
WARNING - 2022-03-10 13:25:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
